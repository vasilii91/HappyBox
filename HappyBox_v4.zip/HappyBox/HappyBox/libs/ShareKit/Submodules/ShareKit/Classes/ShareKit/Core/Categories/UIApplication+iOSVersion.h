//
//  UIApplication+iOSVersion.h
//  ShareKit
//
//  Created by Vilém Kurz on 10/15/13.
//
//

#import <UIKit/UIKit.h>

@interface UIApplication (iOSVersion)

- (BOOL)isiOS6OrOlder;

@end
