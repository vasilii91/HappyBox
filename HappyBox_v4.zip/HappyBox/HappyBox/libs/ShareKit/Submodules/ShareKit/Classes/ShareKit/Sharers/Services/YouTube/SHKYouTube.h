//
//  SHKYouTube.h
//  ShareKit
//
//  Created by Jacob Dunn on 2/26/13.
//
//

#import "SHKSharer.h"

@interface SHKYouTube : SHKSharer

@end
