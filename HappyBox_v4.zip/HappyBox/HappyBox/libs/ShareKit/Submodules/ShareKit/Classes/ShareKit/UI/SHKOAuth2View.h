//
//  SHKImgurOAuthView.h
//  ShareKit
//
//  Created by Andrew Shu on 3/21/14.
//
//

#import "SHKOAuthView.h"

@interface SHKOAuth2View : SHKOAuthView

@end
