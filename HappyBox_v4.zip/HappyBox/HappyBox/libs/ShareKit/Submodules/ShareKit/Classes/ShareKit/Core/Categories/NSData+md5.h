@interface NSData (md5)
- (NSString *) md5;
@end
