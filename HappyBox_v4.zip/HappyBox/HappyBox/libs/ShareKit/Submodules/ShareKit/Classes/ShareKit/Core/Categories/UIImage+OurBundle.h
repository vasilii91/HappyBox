//
//  UIImage+OurBundle.h
//  ShareKit
//
//  Created by Vilem Kurz on 01/08/2013.
//
//

#import <UIKit/UIKit.h>

@interface UIImage (OurBundle)

+ (UIImage *)imageNamedFromOurBundle:(NSString *)name;

@end
