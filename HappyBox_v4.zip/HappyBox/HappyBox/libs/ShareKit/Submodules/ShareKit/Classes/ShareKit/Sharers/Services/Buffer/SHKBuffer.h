//
//  SHKBuffer.h
//  Buffer
//
//  Created by Andrew Yates on 26/04/2013.
//  Copyright (c) 2013 Buffer Inc. All rights reserved.
//

#import "SHKSharer.h"

@interface SHKBuffer : SHKSharer

+ (BOOL)handleOpenURL:(NSURL*)url;

@end
