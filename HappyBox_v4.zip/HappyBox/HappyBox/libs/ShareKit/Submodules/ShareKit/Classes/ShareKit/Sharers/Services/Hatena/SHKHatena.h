//
//  SHKHatena.h
//  ShareKit
//
//  Created by kishikawa katsumi on 2012/09/04.
//
//

#import "SHKOAuthSharer.h"

extern NSString * const kSHKHatenaUserInfo;

@interface SHKHatena : SHKOAuthSharer

@end
