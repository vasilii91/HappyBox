#import <Foundation/Foundation.h>
#import "SHKSharer.h"

@interface SHKPrint : SHKSharer

- (BOOL)print;

@end
