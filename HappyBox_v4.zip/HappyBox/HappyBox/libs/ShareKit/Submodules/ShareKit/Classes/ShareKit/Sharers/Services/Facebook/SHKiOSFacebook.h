//
//  SHKiOSFacebook.h
//  ShareKit
//
//  Created by Vilem Kurz on 18/11/2012.
//
//

#import <UIKit/UIKit.h>
#import "SHKiOSSharer.h"

@interface SHKiOSFacebook : SHKiOSSharer

@end
