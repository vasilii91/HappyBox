//
//  UIImage+fixOrientation.h
//  Tiler
//
//  Created by Alexander on 1/4/13.
//  Copyright (c) 2013 Ocsico. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (fixOrientation)

- (UIImage *)fixOrientation;

@end
