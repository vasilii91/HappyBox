//
//  UserSettings.h
//  changes
//
//  Created by Vasilii Kasnitski on 2/19/14.
//  Copyright (c) 2014 Vasilii.Kasnitski. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ChangesOneSettings;

@interface UserSettings : NSObject

+ (UserSettings *)sharedSingleton;

@end
