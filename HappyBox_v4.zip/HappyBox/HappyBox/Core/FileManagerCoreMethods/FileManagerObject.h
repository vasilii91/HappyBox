//
//  FileManagerCoreMethods.m
//  changes
//
//  Created by Vasilii Kasnitski on 2/19/14.
//  Copyright (c) 2014 Vasilii.Kasnitski. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FileManagerObject : NSObject

@property (nonatomic, retain) NSString *pathToImage;
@property (nonatomic, retain) NSString *pathToImagePreview;

@end
