//
//  SOSHKConfigurator.h
//  sochi
//
//  Created by Vasilii Kasnitski on 11/21/13.
//  Copyright (c) 2013 измайлов. All rights reserved.
//

#import "DefaultSHKConfigurator.h"

@interface SHKConfigurator : DefaultSHKConfigurator

@end
